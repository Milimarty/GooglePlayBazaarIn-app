from django.apps import AppConfig


class GoogleBazaarPaymentConfig(AppConfig):
    name = 'google_bazaar_payment'
